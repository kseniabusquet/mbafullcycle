export default class Invoice {

	constructor (readonly date: Date, readonly amount: number) {
	}
}
