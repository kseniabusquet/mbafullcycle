export class PaymentGateway {
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  constructor() {}
  //private IPayPal, private IStripe

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  async payment({ token, amount }): Promise<any> {}
}
